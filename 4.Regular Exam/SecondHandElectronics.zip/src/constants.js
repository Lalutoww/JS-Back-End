const constants = {
   PORT: 3000,
   URL: 'mongodb://localhost:27017/second-hand-electronics',
   SECRET: '70e16630-5f7d-4deb-bc39-0a7c427d5af2',
};

module.exports = constants;
